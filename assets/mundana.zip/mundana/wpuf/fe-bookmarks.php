<?php
/* Get user info. */
global $id;
global $current_user, $wp_roles;
$user = wp_get_current_user();

get_template_part('partials/bookmarks'); ?>